
public class BattleShipGame
{
	public static void main(String[] args)
	{
		BattleShip Player1 = new BattleShip();
		Player1.ClearBoard();
	}
}
